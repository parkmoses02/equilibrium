# ESP32-WROVER-CAM + TMC5160T Pro Carrier Rev.A

This is a placement/net-assignment draft for KiCad 8/9, reconstructed from the supplied images.

## Mechanical assumptions

- PCB: 100 x 80 mm, four M3 holes at 5 mm inset
- ESP32 headers: 2.54 mm pitch, 20 positions per side, assumed 27.94 mm row spacing
- TMC5160T Pro: 2.54 mm pitch, 8 positions per side, assumed 15.24 mm row spacing
- Motor connector: 5.08 mm pitch; other signal connectors: 2.54 mm

## Electrical rules

- VMOT is isolated from +5V and accepts the motor supply.
- TMC5160 VIO is connected to ESP32 3.3 V.
- All grounds are common.
- GPIO6-11 and GPIO16-17 are intentionally unused.
- Rev.A assumes the camera is not used at the same time.

## Important status

The PCB contains footprints and logical nets, but copper routing is intentionally not finalized until the physical row spacing and orientation are checked against the actual modules. Do not order this revision. Open it in KiCad, place the real modules over a 1:1 print, and confirm the headers before routing.
